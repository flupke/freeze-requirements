from setuptools import setup

setup(name="simple-setuptools")
