from distutils.core import setup

setup(name="simple-distutils")
